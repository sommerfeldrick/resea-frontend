# 🚀 Instruções Finais de Upload - Resea AI

## ✅ Status Atual

**Backend**: ✅ Rodando no Render.com
- URL: https://resea-backend.onrender.com
- Status: Live e funcionando
- API Key Groq: Configurada

**Frontend**: 📦 Pronto para upload no Hostinger

---

## 📂 O que fazer upload

Faça upload **APENAS** dos arquivos dentro da pasta `public_html/`:

```
public_html/
├── index.html        ← Frontend conectado à API do Render
├── .htaccess         ← Configuração Apache (SPA fallback)
└── favicon.ico       ← Ícone do site
```

**❌ NÃO** precisa mais da pasta `backend/` - ela está rodando no Render!

---

## 📤 Como fazer o upload

### Opção 1: Via File Manager do cPanel

1. Acesse o cPanel do Hostinger
2. Abra **File Manager**
3. Navegue até: `/home/wwsmil/app.smileai.com.br/public_html/`
4. **Delete** tudo que está lá dentro (se houver)
5. Faça upload dos 3 arquivos:
   - `index.html`
   - `.htaccess`
   - `favicon.ico`

### Opção 2: Via FTP (FileZilla)

1. Conecte via FTP:
   - **Host**: ftp.app.smileai.com.br
   - **Usuário**: wwsmil
   - **Porta**: 21
2. Navegue até: `/home/wwsmil/app.smileai.com.br/public_html/`
3. Faça upload dos 3 arquivos

---

## ✅ Testando

Depois do upload, acesse:

👉 **https://app.smileai.com.br/**

Você deve ver:
- ✅ Página bonita com gradiente roxo
- ✅ Status: "API Conectada - running"
- ✅ Links funcionando para Ver Status da API

Se clicar em "Ver Status da API", deve abrir:
- https://resea-backend.onrender.com/api/health

E mostrar JSON com status: "running"

---

## 🎯 Endpoints Disponíveis

### Autenticação (SmileAI OAuth)
- `POST https://resea-backend.onrender.com/api/auth/login`
- `GET https://resea-backend.onrender.com/api/auth/me`
- `GET https://resea-backend.onrender.com/api/auth/profile`

### Pesquisa Acadêmica
- `POST https://resea-backend.onrender.com/api/task-plan` - Gerar plano de pesquisa
- `POST https://resea-backend.onrender.com/api/research-step` - Executar etapa de pesquisa
- `POST https://resea-backend.onrender.com/api/mind-map` - Gerar mapa mental

### SmileAI Integration
- `GET https://resea-backend.onrender.com/api/auth/smileai/documents`
- `GET https://resea-backend.onrender.com/api/auth/smileai/templates`
- `GET https://resea-backend.onrender.com/api/auth/smileai/brand-voice`

---

## 🔧 Configurações Importantes

### No Render (Backend)
✅ Já configurado:
- `GROQ_API_KEY` = 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
- `NODE_ENV` = production
- `PORT` = 3001
- `ENABLE_WEB_SCRAPING` = true

### No Hostinger (Frontend)
✅ Apenas HTML estático - nenhuma configuração necessária!

---

## 📊 Arquitetura Final

```
┌─────────────────────────────────────┐
│  Frontend (Hostinger)               │
│  app.smileai.com.br                 │
│  - index.html (HTML/JS puro)        │
└─────────────┬───────────────────────┘
              │
              │ HTTPS
              ↓
┌─────────────────────────────────────┐
│  Backend (Render.com)               │
│  resea-backend.onrender.com         │
│  - Node.js + Express + TypeScript   │
│  - Multi-AI (Groq, Gemini, etc)     │
│  - Web Scraping                     │
│  - SmileAI OAuth                    │
└─────────────────────────────────────┘
```

---

## 🎉 Benefícios desta Arquitetura

1. ✅ **Zero custo no Hostinger** - só HTML estático
2. ✅ **Backend gratuito no Render** - 750h/mês free
3. ✅ **Não sobrecarrega seu VPS** - backend separado
4. ✅ **Escalável** - Render auto-escala se necessário
5. ✅ **Deploy automático** - Push no GitHub = Deploy automático
6. ✅ **SSL gratuito** - Render fornece HTTPS automático

---

## 🚨 Importante

### Limitações do Plano Free do Render:
- ⏰ **Spin down após 15min** de inatividade
- ⏱️ **50 segundos** para "acordar" na primeira requisição
- 🔄 **Solução**: Primeira requisição sempre demora, depois fica rápido

### Para evitar o spin down:
- Upgrade para plano pago ($7/mês)
- Ou use serviço de ping (UptimeRobot) para manter ativo

---

## 📝 Próximos Passos (Opcional)

Se quiser melhorar:

1. **Frontend React compilado** - Interface mais rica
2. **Domínio customizado** - ex: api.smileai.com.br
3. **Banco de dados** - Persistir dados de usuários
4. **Analytics** - Google Analytics ou Plausible
5. **Monitoramento** - Sentry para erros

---

🎉 **PRONTO! Site funcionando com backend na nuvem!**
